declare module "@cypress/browserify-preprocessor";

declare module "pngjs";

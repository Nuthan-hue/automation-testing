# Localisation

Cucumber keywords have been translated to multiple languages and can be used like shown below. See Cucumber's own [documentation](https://cucumber.io/docs/gherkin/languages/) for supported languages.

```gherkin
# language: no
Egenskap: en funksjonalitet
  Scenario: et scenario
    Gitt et steg
```

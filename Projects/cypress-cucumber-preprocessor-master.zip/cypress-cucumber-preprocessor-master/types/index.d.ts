// Minimum TypeScript Version: 3.9

/// <reference types="cypress" />
/// <reference types=".." />

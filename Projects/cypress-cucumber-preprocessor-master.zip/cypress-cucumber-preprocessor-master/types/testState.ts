window.testState.gherkinDocument; // $ExpectType IGherkinDocument
window.testState.pickles; // $ExpectType IPickle[]
window.testState.pickle; // $ExpectType IPickle

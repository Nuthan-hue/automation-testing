export * from "./lib/methods";

export { default as DataTable } from "./lib/data_table";

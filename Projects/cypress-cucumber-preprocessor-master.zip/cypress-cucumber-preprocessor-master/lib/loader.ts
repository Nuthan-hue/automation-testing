import { compile } from "./template";

export default compile;

import debug from "debug";

export default debug("cypress-cucumber-preprocessor");
